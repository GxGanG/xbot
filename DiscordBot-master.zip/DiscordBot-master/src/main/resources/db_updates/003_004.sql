ALTER TABLE servers
  ADD active INT NULL;